DROP TABLE IF EXISTS public.sessions;
